if (!require("BiocManager", quietly = TRUE))
    install.packages("BiocManager")

BiocManager::install("ComplexHeatmap")

library(RColorBrewer)
library(ComplexHeatmap)
library(circlize)
library(gplots)
library(readxl)

merged_df <- read.csv("D:\\Heatmap\\data.csv", header=TRUE)

#0.5/1/2/3/4/8 info
hearing_thresholds <- read.csv("D:\\Heatmap\\Patients_Hearing_Thresholds_G2_mvr.csv", header=TRUE)
hearing_thresholds <- hearing_thresholds[c(1,5:48),] 

data <- merged_df[, c(7,11:54)] # generate data_matrix from column 2 to 45 of a data #exclude 3/4/5 row 
data <- data.frame(data)
rownames(data) <- paste0(merged_df$V1, "(", merged_df$Gene_name, ")")

rownames(data)

top_ha <- HeatmapAnnotation(
  Condition =  cbind(c("HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","HL","C","C","C","C","C","C","C","C","C","C","C","C","C","C","C")),
  Gender =  cbind(c("M","M","M","F","F","M","M","M","F","M","F","M","F","M","F","F","M","F","M","F","M","F","M","M","F","F","F","M","M","F","F","F","F","F","F","F","F","M","F","M","F","F","M","M","F")),
  col = list(Condition=c("HL"="pink","C"="green"),
             Gender = c("F" = "#FF8C00", "M" = "#01b8aa")
  ),
  Age = anno_barplot(
    hearing_thresholds$Age,
    border = FALSE,
    bar_width = 0.618, height = unit(3, "cm"),
    gp = gpar(fill="Dimgrey", col="Dimgrey"),
    axis_param = list(side="right", gp=gpar(fontsize=8))
  ),
  X0.5kHz = anno_barplot(
    hearing_thresholds$X0.5kHz,
    border = FALSE,
    bar_width = 0.618, height = unit(3, "cm"),
    gp = gpar(fill="Dimgrey", col="Dimgrey"),
    axis_param = list(side="right", gp=gpar(fontsize=8))
  ),
  X1kHz = anno_barplot(
    hearing_thresholds$X1kHz,
    border = FALSE,
    bar_width = 0.618, height = unit(3, "cm"),
    gp = gpar(fill="Dimgrey", col="Dimgrey"),
    axis_param = list(side="right", gp=gpar(fontsize=8))
  ),
  X2kHz = anno_barplot(
    hearing_thresholds$X2kHz,
    border = FALSE,
    bar_width = 0.618, height = unit(3, "cm"),
    gp = gpar(fill="Dimgrey", col="Dimgrey"),
    axis_param = list(side="right", gp=gpar(fontsize=8))
  ),
  X3kHz = anno_barplot(
    hearing_thresholds$X3kHz,
    border = FALSE,
    bar_width = 0.618, height = unit(3, "cm"),
    gp = gpar(fill="Dimgrey", col="Dimgrey"),
    axis_param = list(side="right", gp=gpar(fontsize=8))
  ),
  X4kHz = anno_barplot(
    hearing_thresholds$X4kHz,
    border = FALSE,
    bar_width = 0.618, height = unit(3, "cm"),
    gp = gpar(fill="Dimgrey", col="Dimgrey"),
    axis_param = list(side="right", gp=gpar(fontsize=8))
  ),
  X8kHz = anno_barplot(
    hearing_thresholds$X8kHz,
    border = FALSE,
    bar_width = 0.618, height = unit(3, "cm"),
    gp = gpar(fill="Dimgrey", col="Dimgrey"),
    axis_param = list(side="right", gp=gpar(fontsize=8))
  ),
  na_col = "black",
  height = unit(8, "cm"),
  annotation_name_gp = gpar(fontsize = 10,fontface = "bold" ),
  annotation_name_rot = 0,  # Set to 0 to make names horizontal
  show_legend = c("Condition" = TRUE,"Gender" = TRUE,"Age" = TRUE)
)

left_ha <- rowAnnotation(
  FC = anno_barplot(
    merged_df$FC,
    border = FALSE,
    bar_width = 0.618, width = unit(1.2, "cm"),
    gp = gpar(fill="Dimgrey", col="Dimgrey"),
    axis_param = list(direction = "reverse", side = "top", gp = gpar(fontsize=8))
  ),
  annotation_name_side = "top"
)

# Hierarchical clustering of both rows and columns
row_clusters <- hclust(dist(data))
col_clusters <- hclust(dist(data))

num_columns <- ncol(data)
group_vector <- rep(NA, num_columns)
group_vector[1:30] <- "HL"
group_vector[31:45] <- "Control"

ordered_indices <- order(factor(group_vector, levels = c("HL", "Control")))

# Define a color scale for the heatmap (e.g., white to blue)
col_fun <- colorRamp2(c(0, 0.5, 1), c("blue", "white", "red"))
#col_fun <- colorRamp2(c(min_value, mid_value, max_value), c("blue", "white", "red"))
col_fun <- colorRampPalette(c("blue", "white", "red"))(100)

ht <- Heatmap(
  as.matrix(data), name = "GE", #col = col_fun, 
  column_split = factor(group_vector, levels = c("HL", "Control")),
  #column_order = column_order,  # Explicit column order
  column_order = ordered_indices,  # Explicit column order
  top_annotation = top_ha,
  left_annotation = left_ha,

  ## cluster
  cluster_rows = TRUE, cluster_columns = TRUE,
  clustering_distance_columns = function(X) dist(X, method="manhattan"),

  ## names
  show_row_names = TRUE, 
  #row_names_side = "right", row_names_gp  = gpar(fontsize = 12),
  show_column_names = FALSE, column_names_side = "bottom", column_names_rot = 90, column_names_gp  = gpar(fontsize = 8),
  
  ## dend
  column_dend_reorder = TRUE,
  # column_dend_height = unit(2, "cm"),
  
  rect_gp = gpar(col="white", lwd=1)
  
)

ht


